var MSG_GIFT = "Thank you to |username| for the gift";
var MSG_WINNER = "Congratulations to |username| for winning";
var MSG_TEST = "Test sound";